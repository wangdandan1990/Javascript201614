/**
 * Created by 39753 on 2016/12/11.
 */
window.onload=function(){
    var oDiv=document.getElementById('div');
    console.log(oDiv)
















}