var b = require('./B');
console.log(b.avg(98, 95, 92, 96, 95, 94, 92, 98, 93, 90));